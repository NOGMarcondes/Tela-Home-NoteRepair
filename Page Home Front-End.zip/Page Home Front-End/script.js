function menuShow() {
    let menuMobile = document.querySelector('.mobile-menu');
    let icon = document.querySelector('.icon');
    let isOpen = menuMobile.classList.contains('open');

    if (isOpen) {
        menuMobile.classList.remove('open');
        icon.src = "img/menu_white_36dp.svg";
    } else {
        menuMobile.classList.add('open');
        icon.src = "img/close_white_36dp.svg";
    }
}